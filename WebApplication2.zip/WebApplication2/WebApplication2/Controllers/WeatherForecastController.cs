using Microsoft.AspNetCore.Mvc;

namespace WebApplication2.Controllers;

[ApiController]
[Route("[controller]")]
public class WeatherForecastController(
    ILogger<WeatherForecastController> logger)
    : ControllerBase
{
    private static readonly string[] Summaries = new[]
    {
        "Freezing", "Bracing", "Chilly", "Cool", "Mild", "Warm",                      
        "Balmy", "Hot", "Sweltering", "Scorching"
    };

    [HttpGet(Name = "GetWeatherForecast")]
    public IEnumerable<WeatherForecast> Get()
    {
        logger.LogDebug("Inside GetWeatherForecast endpoint");
        logger.LogError("Inside GetWeatherForecast endpoint");
        logger.LogInformation("     qInside GetWeatherForecast endpoint");
        var r = Enumerable.Range(1, 5).Select(index => new WeatherForecast
            {
                Date = DateOnly.FromDateTime(DateTime.Now.AddDays(index)),
                TemperatureC = Random.Shared.Next(-20, 55),
                Summary = Summaries[Random.Shared.Next(Summaries.Length)]
            })
            .ToArray();
        logger.LogDebug($"The response for the get weather " +
                        $"forecast is " +
                        $"{System.Text.Json.JsonSerializer.Serialize(r)}");
        throw new Exception("Failed to retrieve data");

        return r;
    }
}