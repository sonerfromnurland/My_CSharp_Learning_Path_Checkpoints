using WebApplication2.Contracts;

namespace WebApplication2.Models;

public class RequestResponseLogger(ILogger<RequestResponseLogger> logger)
    : IRequestResponseLogger
{
    public void Log(IRequestResponseLogModelCreator logCreator)
    {
        //_logger.LogTrace(jsonString);
        //_logger.LogInformation(jsonString);
        //_logger.LogWarning(jsonString);
        logger.LogCritical(logCreator.LogString());
    }
}