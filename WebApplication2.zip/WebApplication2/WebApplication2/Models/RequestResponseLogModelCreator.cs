
using Newtonsoft.Json;

namespace WebApplication2.Models;

public class RequestResponseLogModelCreator
    : IRequestResponseLogModelCreator
{
    public RequestResponseLogModel LogModel { get; } = new();
    
    public string LogString()
    {
        var jsonString = Newtonsoft.Json.JsonConvert.SerializeObject(LogModel, Formatting.Indented);
        return jsonString;
    }
    
}