using Serilog;
using WebApplication2.Contracts;
using WebApplication2.Controllers;
using WebApplication2.Middleware;
using WebApplication2.Models;
using System.Configuration;

var builder = WebApplication.CreateBuilder(args);

// Add services to the container.

builder.Services.AddControllers();
// Learn more about configuring Swagger/OpenAPI
// at https://aka.ms/aspnetcore/swashbuckle
builder.Services.AddEndpointsApiExplorer();
builder.Services.AddSwaggerGen();

/*Options*/
builder.Services.AddOptions<RequestResponseLoggerOption>().Bind
    (builder.Configuration.GetSection("RequestResponseLogger")).ValidateDataAnnotations();
/*IOC*/
builder.Services.AddSingleton<IRequestResponseLogger, RequestResponseLogger>();
builder.Services.AddScoped<IRequestResponseLogModelCreator, RequestResponseLogModelCreator>();

var logger = new LoggerConfiguration()
    .ReadFrom.Configuration(builder.Configuration)
    .Enrich.FromLogContext()
    .CreateLogger();
builder.Logging.ClearProviders();
builder.Logging.AddSerilog(logger);

var app = builder.Build();
app.UseMiddleware<RequestResponseLoggerMiddleware>();

// Configure the HTTP request pipeline.
if (app.Environment.IsDevelopment())
{
    app.UseSwagger();
    app.UseSwaggerUI();
}

app.UseHttpsRedirection();

app.UseAuthorization();

app.MapControllers();

app.Run();