

public interface IRequestResponseLogModelCreator
{
    RequestResponseLogModel LogModel { get; }
    string                  LogString();
}