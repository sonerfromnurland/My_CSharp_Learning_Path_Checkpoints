namespace WebApplication2.Contracts;

public interface IRequestResponseLogger
{
    void Log(IRequestResponseLogModelCreator logCreator);
}